# genie

Your personal version of Genie.

## setup

### dependencies
npm/yarn

```
yarn install
```

## dev

```
yarn start
yarn watch-css
```

navigate to localhost:3000
