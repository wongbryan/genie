const Components = ['ButtonBar', 'Image', 'h2', 'Paragraph'];

export default Components;